class CharacterCode{
    public static void main(String[] args){
	System.out.println("8進数表示:\101");
	System.out.println("8進数表示:\102");
	System.out.println("8進数表示:\103");
	System.out.println("16進数表示:\u0061");
	System.out.println("16進数表示:\u0062");
	System.out.println("16進数表示:\u0063");
    }
}
