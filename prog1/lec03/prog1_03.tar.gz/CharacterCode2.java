class CharacterCode2{
    public static void main(String[] args){
	System.out.println("8進数:" + 000);
	System.out.println("8進数:" + 010);
	System.out.println("8進数:" + 0100);
	System.out.println("10進数:" + 10);
	System.out.println("10進数:" + 100);
	System.out.println("16進数:" + 0x1);
	System.out.println("16進数:" + 0x10);
	System.out.println("16進数:" + 0xFF);
    }
}
