class VariedPrint3{
    public static void main(String[] args){
	System.out.println("\'はじめてのJavaプログラム\'");
    }
}
