class VariedPrint{
    public static void main(String[] args){
	System.out.println("はじめてのJavaプログラム");
	System.out.println('A');
	System.out.println(135);
    }
}
