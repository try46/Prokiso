class VariedPrint2{
    public static void main(String[] args){
	System.out.print ("はじめてのJavaプログラム");
	System.out.print ('A');
	System.out.print (135);
    }
}
