class EchoFor{
    public static void main(String[] args){
	int i; //繰り返しのための変数
	
	for(i=0; i<5; i++){
	    System.out.println("ヤッホー");
	}
    }
}
