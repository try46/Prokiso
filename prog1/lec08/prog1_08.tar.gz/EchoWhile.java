class EchoWhile{
    public static void main(String[] args){
	int i; // 繰り返しのための変数
	i = 0;
	while(i<5){
	    System.out.println("ヤッホー");
	    i++;
	}
    }
}
