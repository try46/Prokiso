class EchoDoWhile{
    public static void main(String[] args) {
	int i; // 繰り返しのための変数
	i = 0;
	do{
	    System.out.println("ヤッホー");
	    i++;
	}while(i<5);
    }
}
