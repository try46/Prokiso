class CalMulti{
    public static void main(String[] args){
	int multi; // 積
	multi = 1;
	System.out.println("i multi");
	for(int i=1; i<=10; i++){
	    multi *= i;
	    System.out.println(i + " " + multi);
	}
    } 
}
