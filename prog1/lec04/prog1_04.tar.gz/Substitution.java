class Substitution{
  public static void main(String[] args) {
    int x, y;
    x = 10;
    y = x;
    x = 5;
    System.out.println(x);
    System.out.println(y);
  }
}
