class Initialization{
  public static void main(String[] args) {
    int x;
    x = 10;
    System.out.println(x);
  }
}
