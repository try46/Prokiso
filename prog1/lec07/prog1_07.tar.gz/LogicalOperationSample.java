class LogicalOperationSample{
    public static void main(String[] args){
	int money = 120;
	int numberOfCandies = 0;
	char sizeOfCandy = 'L';
	if(money >= 100 && sizeOfCandy == 'L'){
	    numberOfCandies++;
	}
    }
}
