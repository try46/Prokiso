class Average{
    public static void main(String[] args){
	int score1 = 53;
	int score2 = 85;
	int score3 = 72;
	int sum = score1 + score2 + score3;
	double average = sum/3.0;
	System.out.println("合計: " + sum + "点");
	System.out.println("平均: " + average + "点");
    }
}
