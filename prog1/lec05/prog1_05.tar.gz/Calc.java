class Calc{
    public static void main(String[] args) {
	int x, y;
	x = 5;
	y = 2;
	System.out.println(x+y);
	System.out.println(x-y);
	System.out.println(x*y);
	System.out.println(x/y);
	System.out.println(x%y);
    }
}
