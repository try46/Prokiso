class DoubleToInt{
    public static void main(String[] args) {
	double x = 7.7;
	int y;
	y = (int)x;
	System.out.println(y);
    }
}
