class Priority{
    public static void main(String[] args){
	int x, y, z;
	x = 5;
	y = x + 2 * 3;
	z = (x + 2) * 3;
	System.out.println(y);
	System.out.println(z);
    }
}
