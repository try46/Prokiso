class IntToDouble{
    public static void main(String[] args) {
	int x = 7;
	double y;
	y = x;
	System.out.println(y);
    }
}
