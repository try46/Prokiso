class Circumference{
    public static void main(String[] args) {
	double pai = 3.14;
	int rad = 1;
	System.out.println(2*pai*rad);
    }
}
