class Incre1{
    public static void main(String[] args) {
	int x, y;
	x = 0;
	y = 0;
	y = ++x;
	System.out.println(x);
	System.out.println(y);
    }
}
