class Addition2{
    public static void main(String[] args){
	double x;
	x = 2.3;
	x = x + 1.7;
	System.out.println(x);
    }
}
