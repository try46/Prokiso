class Connection3{
    public static void main(String[] args) {
	System.out.println(80+"7"+"点");
	System.out.println("80"+7+"点");
	System.out.println(80+7+"点");
    }
}
