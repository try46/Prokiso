class IncreDecre{
    public static void main(String[] args) {
	int x, y;
	x = 1;
	y = 1;
	x++;
	y--;
	System.out.println(x);
	System.out.println(y);
    }
}
