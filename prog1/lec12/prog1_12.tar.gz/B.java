class B{
    public static void main(String[] args){
	writeMessage();
	System.out.println("もう一度");
	writeMessage();
    }
    public static void writeMessage(){
	System.out.println("いらっしゃいませ");
	System.out.println("大人は800円です");
	System.out.println("子供は400円です");
	return;
    }
}
