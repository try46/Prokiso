class A{
    public static void main(String[] args){
	System.out.println("いらっしゃいませ");
	System.out.println("大人は800円です");
	System.out.println("子供は400円です");
	System.out.println("もう一度");
	System.out.println("いらっしゃいませ");
	System.out.println("大人は800円です");
	System.out.println("子供は400円です");
    }
}
