class G{
    public static void main(String[] args){
	int ans = squareTwo();
	System.out.println(ans);
    }
    public static int squareTwo(){
	int a = 2*2;
	return a;
    }
}
