class G2{
    public static void main(String[] args){
	System.out.println(squareTwo());
    }
    public static int squareTwo(){
	int a = 2*2;
	return a;
    }
}
