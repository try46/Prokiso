class DoubleLoop{
    public static void main(String[] args){
	System.out.println("i j");
	for(int i=0; i<3; i++){
	    for(int j=0; j<2; j++){
		System.out.println(i + " " + j);
	    }
	}
    }
}
