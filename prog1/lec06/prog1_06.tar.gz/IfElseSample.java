class IfElseSample{
  public static void main(String[] args){
    int money = 90;
    int numberOfCandies = 0;
    double water = 0.0;
    if(money >= 100){
      numberOfCandies++;
    }else{
      water += 0.5;
    }
  }
}
