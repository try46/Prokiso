class IfSample{
  public static void main(String[] args){
    int money = 120;
    int numberOfCandies = 0;
    if(money >= 100){
      numberOfCandies++;
    }
  }
}
