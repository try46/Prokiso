

class Sample1 {
    public static void main(String[] args) {
        System.out.println("Sample1");
    }
}
