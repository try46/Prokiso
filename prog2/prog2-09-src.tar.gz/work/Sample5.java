

class Sample5 {
    public static void main(String[] args) {
        System.out.println("Sample5");
        Foo f = new Foo();
        p02.subp.Baz b = new p02.subp.Baz();
    }
}
