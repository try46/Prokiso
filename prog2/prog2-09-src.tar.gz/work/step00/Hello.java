class Hello {
    public Hello() {
        System.out.println("Hello()");
    }
}