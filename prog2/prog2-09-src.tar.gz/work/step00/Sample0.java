class Sample0 {
    public static void main(String[] args) {
        System.out.println("Sample0クラスのmainを実行");
        Hello h = new Hello();
    }
}