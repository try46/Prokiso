

public class Bar {
    public Bar() {
        System.out.println("p02.Bar()");
    }
}
