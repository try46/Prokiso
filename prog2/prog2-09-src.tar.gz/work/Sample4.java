



class Sample4 {
    public static void main(String[] args) {
        System.out.println("Sample4");
        Foo f = new Foo();
        Bar b = new Bar();
    }
}
