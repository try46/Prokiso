

public class Baz {
    public Baz() {
        System.out.println("p02.subp.Baz()");
    }
}
