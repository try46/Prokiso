

class Sample3 {
    public static void main(String[] args) {
        System.out.println("Sample3");
        Foo f = new Foo();
        p02.Foo b = new p02.Foo();
    }
}
